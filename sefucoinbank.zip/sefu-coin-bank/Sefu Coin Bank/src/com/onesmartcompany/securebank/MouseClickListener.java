package com.onesmartcompany.securebank;

import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JList;
import javax.swing.SwingUtilities;

public class MouseClickListener extends MouseAdapter {
	JList list;

	public MouseClickListener(JList jlist) {
		this.list = jlist;
	}// END CONSTRUCTOR

	public void mousePressed(MouseEvent e) {
		if (e.isPopupTrigger() && SwingUtilities.isRightMouseButton(e)) {
			check(e);
		}
	}

	public void mouseReleased(MouseEvent e) {
		if (e.isPopupTrigger() && SwingUtilities.isRightMouseButton(e)) {
			check(e);

		} else if (SwingUtilities.isLeftMouseButton(e)) {
			// System.out.println("LEFTMouse");
			list.setSelectedIndex(list.locationToIndex(e.getPoint()));
			System.out.println("LEFT INDEX: " + list.getSelectedIndex());
		}
	}

	public void check(MouseEvent e) {
		list.setSelectedIndex(list.locationToIndex(e.getPoint()));

		int index = list.getSelectedIndex();
		Rectangle bounds = list.getCellBounds(0, index);

		if (bounds != null && bounds.contains(e.getPoint())) {
			RightClick_PopupMenu menu = new RightClick_PopupMenu(list);
			menu.show(e.getComponent(), e.getX(), e.getY());
		}

	}
}// END CLASS
