package com.onesmartcompany.securebank;

import java.awt.Color;
import java.awt.Dialog;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.ParseException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.text.MaskFormatter;

public class Main_Swing implements ActionListener {

	private JFrame mainJFrame;
	public String appnameString = "Sefu Coin Bank";
	public String versionString = "0.02alpha";
	public String titleString = appnameString + " v" + versionString;
	public String reldateString = "10-Apr-2013";
	public String aboutString = appnameString
			+ "\n"
			+ "A secure, convenient multi-cryptocurrency, multi-wallet management app.\n\n"
			+ "Website: http://www.onesmartcompany.com" + "\n" + "Version: "
			+ versionString + "\n" + "Release Date: " + reldateString;

	public static final String reportBugURL = "http://code.google.com/p/sefu-coin-bank/issues/entry?template=Defect%20report%20from%20user";
	public static final String FAQURL = "http://code.google.com/p/sefu-coin-bank/wiki/FAQ";
	// TODO configure video tutorials URL
	public static final String videoTutorialsURL = "";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_Swing window = new Main_Swing();
					window.mainJFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main_Swing() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */

	private void initialize() {
		mainJFrame = new JFrame(appnameString);
		mainJFrame.setTitle(titleString);
		mainJFrame.setResizable(false);
		mainJFrame.setBounds(100, 100, 1026, 802);
		mainJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		mainJFrame.getContentPane().setLayout(springLayout);

		// ///////////////////////////////////////////////////////////////
		// Wallet panel
		// ///////////////////////////////////////////////////////////////
		JPanel wallet_panel = new JPanel();
		springLayout.putConstraint(SpringLayout.NORTH, wallet_panel, 0,
				SpringLayout.NORTH, mainJFrame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, wallet_panel, 0,
				SpringLayout.WEST, mainJFrame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, wallet_panel, 194,
				SpringLayout.WEST, mainJFrame.getContentPane());
		wallet_panel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));

		wallet_panel.setLayout(null);
		UIManager.put("Tree.rendererFillBackground", false);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_1.setBounds(10, 48, 172, 577);
		wallet_panel.add(scrollPane_1);

		List wallet_list = new List();
		wallet_list.setFont(new Font("Tahoma", Font.BOLD, 18));
		scrollPane_1.setViewportView(wallet_list);
		wallet_list.setBackground(UIManager.getColor("Panel.background"));

		wallet_list.add("My Wallet 1");
		wallet_list.add("My Wallet 2");
		wallet_list.add("My Wallet 3");

		JLabel lblWallets = new JLabel("Wallets");
		lblWallets.setBounds(12, 13, 94, 29);
		lblWallets.setFont(new Font("Tahoma", Font.BOLD, 24));
		wallet_panel.add(lblWallets);

		JButton btnNewWallet = new JButton("New...");
		btnNewWallet.setActionCommand("New Wallet");
		btnNewWallet.addActionListener(this);
		btnNewWallet.setBounds(106, 13, 76, 29);
		wallet_panel.add(btnNewWallet);
		mainJFrame.getContentPane().add(wallet_panel);

		// ///////////////////////////////////////////////////////////////
		// Ads panel
		// ///////////////////////////////////////////////////////////////
		JPanel ads_panel = new JPanel();
		springLayout.putConstraint(SpringLayout.SOUTH, wallet_panel, -6,
				SpringLayout.NORTH, ads_panel);
		ads_panel.setBorder(new LineBorder(Color.RED, 2, true));
		springLayout.putConstraint(SpringLayout.NORTH, ads_panel, -90,
				SpringLayout.SOUTH, mainJFrame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, ads_panel, 0,
				SpringLayout.WEST, mainJFrame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, ads_panel, 0,
				SpringLayout.SOUTH, mainJFrame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, ads_panel, 1008,
				SpringLayout.WEST, mainJFrame.getContentPane());
		mainJFrame.getContentPane().add(ads_panel);

		// ///////////////////////////////////////////////////////////////
		// Transaction panel
		// ///////////////////////////////////////////////////////////////
		JPanel transaction_panel = new JPanel();
		transaction_panel
				.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		mainJFrame.getContentPane().add(transaction_panel);
		transaction_panel.setLayout(null);
		JTabbedPane transaction_tabbedpane = new JTabbedPane(JTabbedPane.TOP);
		transaction_tabbedpane.setBounds(12, 55, 784, 349);
		transaction_panel.add(transaction_tabbedpane);
		JLabel lblTransactionManager = new JLabel("Transaction Manager");
		lblTransactionManager.setBounds(12, 13, 261, 29);
		lblTransactionManager.setFont(new Font("Tahoma", Font.BOLD, 24));
		transaction_panel.add(lblTransactionManager);

		// Accounts tab
		JPanel accounts_tab = new JPanel();
		transaction_tabbedpane
				.addTab("Accounts",
						new ImageIcon(
								Main_Swing.class
										.getResource("/javax/swing/plaf/metal/icons/ocean/homeFolder.gif")),
						accounts_tab, null);
		accounts_tab.setLayout(null);

		JScrollPane acct_scrollpane = new JScrollPane();
		acct_scrollpane
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		acct_scrollpane.setBounds(10, 44, 757, 265);
		accounts_tab.add(acct_scrollpane);

		// Acct Name = 24 chars
		// Acct Type = 3 chars
		// Acct Address = 34 chars
		// Acct Bal = 15 chars

		String acct_space = "";
		String type_space = "         ";
		String addr_space = "    ";

		String testString = "Account12345            " + acct_space + "BTC"
				+ type_space + "LarMXickWriouNeHxdekosBHEaJGQ4sjif"
				+ addr_space + "9999999.99999999";

		String testString2 = "Account67890            " + acct_space + "LTC"
				+ type_space + "LarMXick123ouNeHxdekosBHEaJGQ4sjif"
				+ addr_space + "1234567.99999999";

		DefaultListModel listModel = new DefaultListModel<>();
		listModel.addElement(testString);
		listModel.addElement(testString2);

		JList acct_list = new JList(listModel);
		acct_list.setFont(new Font("Monospaced", Font.PLAIN, 14));
		acct_list.setBackground(Color.WHITE);
		acct_scrollpane.setViewportView(acct_list);
		acct_list.addMouseListener(new MouseClickListener(acct_list));

		JLabel lblAccountName = new JLabel("Account Name");
		lblAccountName.setHorizontalAlignment(SwingConstants.LEFT);
		lblAccountName.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblAccountName.setBounds(12, 13, 127, 29);
		accounts_tab.add(lblAccountName);

		JLabel lblType = new JLabel("Currency");
		lblType.setHorizontalAlignment(SwingConstants.LEFT);
		lblType.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblType.setBounds(199, 13, 86, 29);
		accounts_tab.add(lblType);

		JLabel lblAddress = new JLabel("Address");
		lblAddress.setHorizontalAlignment(SwingConstants.LEFT);
		lblAddress.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblAddress.setBounds(297, 13, 104, 29);
		accounts_tab.add(lblAddress);

		JLabel lblBalance = new JLabel("Balance");
		lblBalance.setHorizontalAlignment(SwingConstants.LEFT);
		lblBalance.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblBalance.setBounds(602, 13, 77, 29);
		accounts_tab.add(lblBalance);

		JButton btnNewAcct = new JButton("New...");
		btnNewAcct.setActionCommand("New Acct");
		btnNewAcct.addActionListener(this);
		btnNewAcct.setBounds(690, 11, 76, 29);
		accounts_tab.add(btnNewAcct);

		MaskFormatter send_to_mask = null;
		try {
			send_to_mask = new MaskFormatter(
					"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Send tab
		JPanel send_tab = new JPanel();
		transaction_tabbedpane
				.addTab("Send",
						new ImageIcon(
								Main_Swing.class
										.getResource("/javax/swing/plaf/metal/icons/ocean/maximize.gif")),
						send_tab, null);
		send_tab.setLayout(null);

		JLabel lblSendAmount = new JLabel("Send Amount:");
		lblSendAmount.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblSendAmount.setBounds(12, 13, 121, 16);
		send_tab.add(lblSendAmount);

		JLabel lblToAddress = new JLabel("To Address:");
		lblToAddress.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblToAddress.setBounds(12, 63, 97, 16);
		send_tab.add(lblToAddress);

		JLabel lblSendBy = new JLabel("Send By:");
		lblSendBy.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblSendBy.setBounds(519, 13, 83, 16);
		send_tab.add(lblSendBy);

		JComboBox send_currency = new JComboBox();
		send_currency.setFont(new Font("Tahoma", Font.BOLD, 16));
		send_currency.setModel(new DefaultComboBoxModel(new String[] { "BTC",
				"LTC", "NMC" }));
		send_currency.setMaximumRowCount(3);
		send_currency.setBounds(320, 10, 83, 22);
		send_tab.add(send_currency);

		JComboBox send_by = new JComboBox();
		send_by.setToolTipText("See Settings to change fees for each send method.\r\nGenerally, the more you pay in fees, the faster your transaction.");
		send_by.setModel(new DefaultComboBoxModel(new String[] { "Standard",
				"Expedited", "Escrow" }));
		send_by.setMaximumRowCount(3);
		send_by.setFont(new Font("Tahoma", Font.BOLD, 16));
		send_by.setBounds(614, 10, 153, 22);
		send_tab.add(send_by);

		JFormattedTextField send_amt = new JFormattedTextField();
		send_amt.setText("0.00000000");
		send_amt.setToolTipText("Enter amount of this currency to SEND.\r\nFor example: 1987.10912345 (up to 8 decimal places)");
		send_amt.setHorizontalAlignment(SwingConstants.RIGHT);
		send_amt.setFont(new Font("Tahoma", Font.PLAIN, 16));
		send_amt.setBounds(145, 10, 165, 22);
		send_tab.add(send_amt);

		JFormattedTextField send_to = new JFormattedTextField(send_to_mask);
		send_to.setToolTipText("Enter the address you wish to send to.");
		send_to.setHorizontalAlignment(SwingConstants.RIGHT);
		send_to.setFont(new Font("Tahoma", Font.PLAIN, 16));
		send_to.setBounds(145, 61, 258, 22);
		send_tab.add(send_to);

		JLabel lblFromAccount = new JLabel("From Account:");
		lblFromAccount.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblFromAccount.setBounds(476, 63, 126, 16);
		send_tab.add(lblFromAccount);

		JComboBox send_from = new JComboBox();
		send_from.setModel(new DefaultComboBoxModel(new String[] {
				"AcctName1234", "AcctName2345", "AcctName3456" }));
		send_from.setMaximumRowCount(3);
		send_from.setFont(new Font("Tahoma", Font.BOLD, 16));
		send_from.setBounds(614, 60, 153, 22);
		send_tab.add(send_from);

		JLabel lblMessageoptional = new JLabel("Message (OPTIONAL):");
		lblMessageoptional.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblMessageoptional.setBounds(12, 115, 192, 22);
		send_tab.add(lblMessageoptional);

		JTextField send_msg = new JTextField();
		send_msg.setHorizontalAlignment(SwingConstants.LEFT);
		send_msg.setToolTipText("(OPTIONAL) Enter a small message to send along with your payment.");
		send_msg.setBounds(216, 116, 551, 21);
		send_tab.add(send_msg);
		send_msg.setColumns(10);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Paste QR Code Here",
				TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panel.setBounds(6, 164, 151, 149);
		send_tab.add(panel);
		panel.setLayout(null);

		JEditorPane send_qr_code = new JEditorPane();
		send_qr_code.setBounds(6, 18, 139, 124);
		panel.add(send_qr_code);
		send_qr_code.setToolTipText("Paste QR Code Here");

		JButton btnSend = new JButton("SEND");
		btnSend.addActionListener(this);
		btnSend.setToolTipText("WARNING: Sending funds by any method OTHER than Escrow is FINAL.");
		btnSend.setBounds(691, 173, 76, 29);
		send_tab.add(btnSend);

		// Receive tab
		JPanel request_tab = new JPanel();
		transaction_tabbedpane
				.addTab("Request",
						new ImageIcon(
								Main_Swing.class
										.getResource("/javax/swing/plaf/metal/icons/ocean/minimize.gif")),
						request_tab, null);
		request_tab.setLayout(null);

		JLabel lblRequestAmount = new JLabel("Request Amount:");
		lblRequestAmount.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblRequestAmount.setBounds(18, 16, 145, 16);
		request_tab.add(lblRequestAmount);

		JFormattedTextField trans_req_amt = new JFormattedTextField();
		trans_req_amt
				.setToolTipText("Enter amount of this currency to REQUEST\r\nFor example: 1987.10912345 (up to 8 decimal places)");
		trans_req_amt.setText("0.00000000");
		trans_req_amt.setHorizontalAlignment(SwingConstants.RIGHT);
		trans_req_amt.setFont(new Font("Tahoma", Font.PLAIN, 16));
		trans_req_amt.setBounds(175, 13, 165, 22);
		request_tab.add(trans_req_amt);

		JComboBox trans_req_currency1 = new JComboBox();
		trans_req_currency1.setModel(new DefaultComboBoxModel(new String[] {
				"BTC", "LTC", "NMC" }));
		trans_req_currency1.setMaximumRowCount(3);
		trans_req_currency1.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_req_currency1.setBounds(352, 13, 83, 22);
		request_tab.add(trans_req_currency1);

		JLabel lblApprox = new JLabel("Approx.");
		lblApprox.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblApprox.setBounds(447, 16, 66, 16);
		request_tab.add(lblApprox);

		JLabel lblIntoAccount = new JLabel("Into Account:");
		lblIntoAccount.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblIntoAccount.setBounds(225, 67, 115, 16);
		request_tab.add(lblIntoAccount);

		JComboBox trans_req_acct = new JComboBox();
		trans_req_acct.setModel(new DefaultComboBoxModel(new String[] {
				"AcctName1234", "AcctName2345", "AcctName3456" }));
		trans_req_acct.setMaximumRowCount(3);
		trans_req_acct.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_req_acct.setBounds(352, 64, 153, 22);
		request_tab.add(trans_req_acct);

		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(new TitledBorder(null, "Request QR Code",
				TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panel_1.setBounds(628, 170, 151, 149);
		request_tab.add(panel_1);

		JEditorPane trans_req_qr_code = new JEditorPane();
		trans_req_qr_code.setToolTipText("Scan This QR Code");
		trans_req_qr_code.setBounds(6, 18, 139, 124);
		panel_1.add(trans_req_qr_code);

		JButton btnCopyAddress = new JButton(
				"Copy Account Address To Clipboard");
		btnCopyAddress.setActionCommand("Copy Address");
		btnCopyAddress.addActionListener(this);
		btnCopyAddress
				.setToolTipText("Click to copy the address for the chosen account to your computer clipboard");
		btnCopyAddress.setBounds(530, 62, 237, 29);
		request_tab.add(btnCopyAddress);

		JLabel trans_req_currency2 = new JLabel("$CAD");
		trans_req_currency2.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_req_currency2.setBounds(642, 16, 66, 16);
		request_tab.add(trans_req_currency2);

		JLabel trans_req_exch_curr_sym = new JLabel("$");
		trans_req_exch_curr_sym.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_req_exch_curr_sym.setBounds(515, 16, 26, 16);
		request_tab.add(trans_req_exch_curr_sym);

		JLabel trans_req_exch_amt = new JLabel("9999999.99");
		trans_req_exch_amt.setHorizontalAlignment(SwingConstants.RIGHT);
		trans_req_exch_amt.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_req_exch_amt.setBounds(525, 16, 105, 16);
		request_tab.add(trans_req_exch_amt);

		JButton btnCopyQRCode = new JButton("Copy QR Code To Clipboard");
		btnCopyQRCode.setActionCommand("Copy QR");
		btnCopyQRCode.addActionListener(this);
		btnCopyQRCode
				.setToolTipText("Click to copy the QR Code for the chosen account to your computer clipboard");
		btnCopyQRCode.setBounds(530, 116, 237, 29);
		request_tab.add(btnCopyQRCode);

		// Exchange tab
		JPanel exchange_tab = new JPanel();
		transaction_tabbedpane
				.addTab("Exchange",
						new ImageIcon(
								Main_Swing.class
										.getResource("/javax/swing/plaf/metal/icons/ocean/computer.gif")),
						exchange_tab, null);
		exchange_tab.setLayout(null);

		JLabel lblExchangeAmount = new JLabel("Exchange Amount:");
		lblExchangeAmount.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblExchangeAmount.setBounds(12, 16, 159, 16);
		exchange_tab.add(lblExchangeAmount);

		JFormattedTextField trans_exch_howmuch = new JFormattedTextField();
		trans_exch_howmuch
				.setToolTipText("Enter amount of this currency to EXCHANGE\r\nFor example: 1987.10912345 (up to 8 decimal places)");
		trans_exch_howmuch.setText("0.00000000");
		trans_exch_howmuch.setHorizontalAlignment(SwingConstants.RIGHT);
		trans_exch_howmuch.setFont(new Font("Tahoma", Font.PLAIN, 16));
		trans_exch_howmuch.setBounds(169, 13, 165, 22);
		exchange_tab.add(trans_exch_howmuch);

		JComboBox trans_exch_currency1 = new JComboBox();
		trans_exch_currency1.setModel(new DefaultComboBoxModel(new String[] {
				"BTC", "LTC", "NMC" }));
		trans_exch_currency1.setMaximumRowCount(3);
		trans_exch_currency1.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_exch_currency1.setBounds(346, 13, 83, 22);
		exchange_tab.add(trans_exch_currency1);

		JLabel label_15 = new JLabel("Approx.");
		label_15.setFont(new Font("Tahoma", Font.BOLD, 16));
		label_15.setBounds(441, 16, 66, 16);
		exchange_tab.add(label_15);

		JLabel trans_exch_currency_symbol = new JLabel("$");
		trans_exch_currency_symbol.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_exch_currency_symbol.setBounds(509, 16, 26, 16);
		exchange_tab.add(trans_exch_currency_symbol);

		JLabel trans_exch_amt = new JLabel("9999999.99");
		trans_exch_amt.setHorizontalAlignment(SwingConstants.RIGHT);
		trans_exch_amt.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_exch_amt.setBounds(519, 16, 105, 16);
		exchange_tab.add(trans_exch_amt);

		JLabel trans_exch_currency2 = new JLabel("$CAD");
		trans_exch_currency2.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_exch_currency2.setBounds(636, 16, 66, 16);
		exchange_tab.add(trans_exch_currency2);

		JLabel label_20 = new JLabel("Into Account:");
		label_20.setFont(new Font("Tahoma", Font.BOLD, 16));
		label_20.setBounds(219, 67, 115, 16);
		exchange_tab.add(label_20);

		JComboBox trans_exch_acct = new JComboBox();
		trans_exch_acct.setModel(new DefaultComboBoxModel(new String[] {
				"AcctName1234", "AcctName2345", "AcctName3456" }));
		trans_exch_acct.setMaximumRowCount(3);
		trans_exch_acct.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_exch_acct.setBounds(346, 64, 153, 22);
		exchange_tab.add(trans_exch_acct);

		JButton btnExchange = new JButton("EXCHANGE");
		btnExchange.addActionListener(this);

		btnExchange
				.setToolTipText("WARNING: Once you click EXCHANGE, the transaction is final and cannot be reversed!");
		btnExchange.setBounds(519, 92, 105, 29);
		exchange_tab.add(btnExchange);

		JLabel lblUseExchange = new JLabel("Use Exchange:");
		lblUseExchange.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblUseExchange.setBounds(211, 99, 125, 22);
		exchange_tab.add(lblUseExchange);

		JComboBox trans_exch_use_exch = new JComboBox();
		trans_exch_use_exch.setModel(new DefaultComboBoxModel(new String[] {
				"Exchange1", "Exchange2", "Exchange3", "Exchange4" }));
		trans_exch_use_exch.setMaximumRowCount(3);
		trans_exch_use_exch.setFont(new Font("Tahoma", Font.BOLD, 16));
		trans_exch_use_exch.setBounds(346, 99, 153, 22);
		exchange_tab.add(trans_exch_use_exch);

		// Address Book tab
		JPanel address_book_tab = new JPanel();
		transaction_tabbedpane
				.addTab("Address Book",
						new ImageIcon(
								Main_Swing.class
										.getResource("/javax/swing/plaf/metal/icons/ocean/directory.gif")),
						address_book_tab, null);
		address_book_tab.setLayout(null);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 47, 759, 262);
		address_book_tab.add(scrollPane_2);

		List address_list = new List();
		address_list.setFont(new Font("Monospaced", Font.PLAIN, 16));
		scrollPane_2.setViewportView(address_list);

		String addrname_space = "";
		String addrcurr_space = "         ";

		// name = 24 chars
		// currency = 3 chars
		// address = 34 chars

		address_list.add("Todd Brill              " + addrname_space + "BTC"
				+ addrcurr_space + "LarMXickWriouNeHxdekosBHEaJGQ4sjif");
		address_list.add("Joe Blow                " + addrname_space + "LTC"
				+ addrcurr_space + "LarMXickWriouNeHxdekosBHEaJGQ4sjif");
		address_list.add("Mt.Gox BTC Funding      " + addrname_space + "BTC"
				+ addrcurr_space + "LarMXickWriouNeHxdekosBHEaJGQ4sjif");

		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblName.setBounds(12, 13, 67, 28);
		address_book_tab.add(lblName);

		JLabel lblAddress_1 = new JLabel("Address");
		lblAddress_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblAddress_1.setBounds(371, 13, 104, 28);
		address_book_tab.add(lblAddress_1);

		JLabel lblCurrency = new JLabel("Currency");
		lblCurrency.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblCurrency.setBounds(255, 13, 104, 28);
		address_book_tab.add(lblCurrency);

		JButton btn_newAddress = new JButton("New...");
		btn_newAddress.setActionCommand("New Address");
		btn_newAddress.addActionListener(this);
		btn_newAddress.setBounds(691, 15, 76, 29);
		address_book_tab.add(btn_newAddress);

		// History tab
		JPanel history_tab = new JPanel();
		transaction_tabbedpane
				.addTab("History",
						new ImageIcon(
								Main_Swing.class
										.getResource("/javax/swing/plaf/metal/icons/ocean/file.gif")),
						history_tab, null);
		history_tab.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane
				.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 62, 759, 247);
		history_tab.add(scrollPane);

		List trans_list = new List();
		trans_list.setFont(new Font("Monospaced", Font.PLAIN, 12));

		// Datetime = 11 chars
		// Type = 4 chars
		// Acct Names = 12 chars (TRUNCT)
		// Acct Types = 3 chars
		// Acct Addresses = 34 chars
		// Fee = 5 chars
		// Status = 8 chars

		String datetime_space = " ";
		String transtype_space = " ";
		String facct_space = " ";
		String fcur_space = " ";
		String famt_space = " ";
		String fee_space = " ";
		String tacct_space = " ";
		String tcur_space = " ";
		String tamt_space = " ";

		trans_list.add("13-Mar-2013" + datetime_space + "Exch"
				+ transtype_space + "Account12345" + facct_space + "BTC"
				+ fcur_space + "9999999.99999999" + famt_space + "0.001"
				+ fee_space + "Mt.Gox      " + tacct_space + "CAD" + tcur_space
				+ "9999999.99999999" + tamt_space + "Complete");

		trans_list.add("14-Mar-2013" + datetime_space + "Send"
				+ transtype_space + "Account12345" + facct_space + "LTC"
				+ fcur_space + "9999999.99999999" + famt_space + "0.001"
				+ fee_space + "Todd Brill  " + tacct_space + "LTC" + tcur_space
				+ "9999999.99999999" + tamt_space + "Pending");

		trans_list.add("15-Mar-2013" + datetime_space + "Reqs"
				+ transtype_space + "Account67890" + facct_space + "NMC"
				+ fcur_space + "9999999.99999999" + famt_space + "0.001"
				+ fee_space + "Joe Blow    " + tacct_space + "NMC" + tcur_space
				+ "9999999.99999999" + tamt_space + "Failed");

		trans_list.add("01-Apr-2013" + datetime_space + "Escr"
				+ transtype_space + "Account12345" + facct_space + "BTC"
				+ fcur_space + "9999999.99999999" + famt_space + "0.001"
				+ fee_space + "Todd Brill  " + tacct_space + "BTC" + tcur_space
				+ "9999999.99999999" + tamt_space + "Pending");

		scrollPane.setViewportView(trans_list);

		JButton btnPurgeHistory = new JButton("Purge History");
		btnPurgeHistory.addActionListener(this);
		btnPurgeHistory.setToolTipText("WARNING: This cannot be undone!");
		btnPurgeHistory.setBounds(642, 13, 127, 25);
		history_tab.add(btnPurgeHistory);

		JLabel lblDatetime = new JLabel("Date/Time");
		lblDatetime.setBounds(12, 41, 65, 16);
		history_tab.add(lblDatetime);

		JLabel lblTransType = new JLabel("Type");
		lblTransType.setBounds(96, 41, 38, 16);
		history_tab.add(lblTransType);

		JLabel lblToAcct = new JLabel("Acct");
		lblToAcct.setBounds(412, 41, 65, 16);
		history_tab.add(lblToAcct);

		JLabel lblFromAcct = new JLabel("Acct");
		lblFromAcct.setBounds(135, 41, 65, 16);
		history_tab.add(lblFromAcct);

		JLabel lblAmount = new JLabel("Amt");
		lblAmount.setBounds(535, 41, 40, 16);
		history_tab.add(lblAmount);

		JLabel lblFromAmt = new JLabel("Amt");
		lblFromAmt.setBounds(255, 41, 38, 16);
		history_tab.add(lblFromAmt);

		JLabel lblFromCurr = new JLabel("Curr");
		lblFromCurr.setBounds(222, 41, 65, 16);
		history_tab.add(lblFromCurr);

		JLabel lblToCurr = new JLabel("Curr");
		lblToCurr.setBounds(503, 41, 45, 16);
		history_tab.add(lblToCurr);

		JLabel lblTransStatus = new JLabel("Status");
		lblTransStatus.setBounds(652, 41, 56, 16);
		history_tab.add(lblTransStatus);

		JLabel lblFrom = new JLabel("FROM:");
		lblFrom.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblFrom.setBounds(134, 23, 56, 16);
		history_tab.add(lblFrom);

		JLabel lblTo = new JLabel("TO:");
		lblTo.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblTo.setBounds(412, 22, 56, 16);
		history_tab.add(lblTo);

		JLabel lblFee = new JLabel("Fee");
		lblFee.setBounds(373, 41, 28, 16);
		history_tab.add(lblFee);

		JSeparator separator = new JSeparator();
		separator.setBounds(135, 41, 227, 2);
		history_tab.add(separator);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(412, 41, 227, 2);
		history_tab.add(separator_1);

		// ///////////////////////////////////////////////////////////////
		// Balance panel
		// ///////////////////////////////////////////////////////////////
		JPanel balance_panel = new JPanel();
		balance_panel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		springLayout.putConstraint(SpringLayout.NORTH, balance_panel, 0,
				SpringLayout.NORTH, mainJFrame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, balance_panel, 5,
				SpringLayout.EAST, wallet_panel);
		springLayout.putConstraint(SpringLayout.SOUTH, balance_panel, 212,
				SpringLayout.NORTH, wallet_panel);
		springLayout.putConstraint(SpringLayout.EAST, balance_panel, 484,
				SpringLayout.EAST, wallet_panel);
		mainJFrame.getContentPane().add(balance_panel);
		springLayout.putConstraint(SpringLayout.NORTH, transaction_panel, 6,
				SpringLayout.SOUTH, balance_panel);
		balance_panel.setLayout(null);

		JLabel lblBalanceTotals = new JLabel("Wallet Totals");
		lblBalanceTotals.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblBalanceTotals.setBounds(12, 13, 181, 29);
		balance_panel.add(lblBalanceTotals);
		springLayout.putConstraint(SpringLayout.WEST, transaction_panel, 6,
				SpringLayout.EAST, wallet_panel);
		springLayout.putConstraint(SpringLayout.SOUTH, transaction_panel, 0,
				SpringLayout.SOUTH, wallet_panel);

		springLayout.putConstraint(SpringLayout.EAST, transaction_panel, 0,
				SpringLayout.EAST, ads_panel);
		ads_panel.setLayout(null);
		JLabel lblBitcoin = new JLabel("Bitcoin(BTC)");
		lblBitcoin.setHorizontalAlignment(SwingConstants.RIGHT);
		lblBitcoin.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblBitcoin.setBounds(12, 86, 171, 29);
		balance_panel.add(lblBitcoin);

		JLabel lblLitecoin = new JLabel("Litecoin(LTC)");
		lblLitecoin.setHorizontalAlignment(SwingConstants.RIGHT);
		lblLitecoin.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblLitecoin.setBounds(12, 112, 171, 29);
		balance_panel.add(lblLitecoin);

		JLabel lblNamecoin = new JLabel("Namecoin(NMC)");
		lblNamecoin.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNamecoin.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNamecoin.setBounds(12, 138, 171, 29);
		balance_panel.add(lblNamecoin);

		JLabel label = new JLabel("999999.99999999");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label.setBounds(195, 86, 134, 29);
		balance_panel.add(label);

		JLabel label_1 = new JLabel("999999.99999999");
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_1.setBounds(195, 112, 134, 29);
		balance_panel.add(label_1);

		JLabel label_2 = new JLabel("999999.99999999");
		label_2.setHorizontalAlignment(SwingConstants.RIGHT);
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_2.setBounds(195, 138, 134, 29);
		balance_panel.add(label_2);

		JLabel lblTotalcad = new JLabel("Total($CAD):");
		lblTotalcad.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTotalcad.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTotalcad.setBounds(171, 170, 171, 29);
		balance_panel.add(lblTotalcad);

		JLabel label_3 = new JLabel("9999999.99");
		label_3.setHorizontalAlignment(SwingConstants.RIGHT);
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_3.setBounds(333, 86, 134, 29);
		balance_panel.add(label_3);

		JLabel label_4 = new JLabel("$");
		label_4.setHorizontalAlignment(SwingConstants.RIGHT);
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_4.setBounds(341, 86, 32, 29);
		balance_panel.add(label_4);

		JLabel label_5 = new JLabel("$");
		label_5.setHorizontalAlignment(SwingConstants.RIGHT);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_5.setBounds(341, 112, 32, 29);
		balance_panel.add(label_5);

		JLabel label_6 = new JLabel("9999999.99");
		label_6.setHorizontalAlignment(SwingConstants.RIGHT);
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_6.setBounds(333, 112, 134, 29);
		balance_panel.add(label_6);

		JLabel label_7 = new JLabel("$");
		label_7.setHorizontalAlignment(SwingConstants.RIGHT);
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_7.setBounds(341, 138, 32, 29);
		balance_panel.add(label_7);

		JLabel label_8 = new JLabel("9999999.99");
		label_8.setHorizontalAlignment(SwingConstants.RIGHT);
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_8.setBounds(333, 138, 134, 29);
		balance_panel.add(label_8);

		JLabel label_9 = new JLabel("$");
		label_9.setHorizontalAlignment(SwingConstants.RIGHT);
		label_9.setFont(new Font("Tahoma", Font.BOLD, 16));
		label_9.setBounds(333, 170, 32, 29);
		balance_panel.add(label_9);

		JLabel label_10 = new JLabel("9999999.99");
		label_10.setHorizontalAlignment(SwingConstants.RIGHT);
		label_10.setFont(new Font("Tahoma", Font.BOLD, 16));
		label_10.setBounds(333, 170, 134, 29);
		balance_panel.add(label_10);

		JLabel lblCad = new JLabel("$CAD");
		lblCad.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCad.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCad.setBounds(364, 55, 103, 29);
		balance_panel.add(lblCad);

		// ///////////////////////////////////////////////////////////////
		// Exchange panel
		// ///////////////////////////////////////////////////////////////
		JPanel exchange_panel = new JPanel();
		exchange_panel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		springLayout.putConstraint(SpringLayout.NORTH, exchange_panel, 0,
				SpringLayout.NORTH, mainJFrame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, exchange_panel, 6,
				SpringLayout.EAST, balance_panel);
		springLayout.putConstraint(SpringLayout.SOUTH, exchange_panel, 0,
				SpringLayout.SOUTH, balance_panel);

		springLayout.putConstraint(SpringLayout.EAST, exchange_panel, 0,
				SpringLayout.EAST, ads_panel);
		mainJFrame.getContentPane().add(exchange_panel);
		exchange_panel.setLayout(null);

		JLabel lblExchangeRates = new JLabel("Exchange Rates");
		lblExchangeRates.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblExchangeRates.setBounds(12, 13, 204, 29);
		exchange_panel.add(lblExchangeRates);

		JButton btnNewExchange = new JButton("New...");
		btnNewExchange.setActionCommand("New Exchange");
		btnNewExchange.addActionListener(this);
		btnNewExchange.setBounds(236, 13, 76, 29);
		exchange_panel.add(btnNewExchange);

		JLabel lblExchange = new JLabel("Exchange");
		lblExchange.setHorizontalAlignment(SwingConstants.LEFT);
		lblExchange.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblExchange.setBounds(12, 55, 104, 22);
		exchange_panel.add(lblExchange);

		JLabel lblConversion = new JLabel("1 unit");
		lblConversion.setHorizontalAlignment(SwingConstants.LEFT);
		lblConversion.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblConversion.setBounds(104, 55, 89, 22);
		exchange_panel.add(lblConversion);

		JLabel exch_currency = new JLabel("$CAD");
		exch_currency.setHorizontalAlignment(SwingConstants.RIGHT);
		exch_currency.setFont(new Font("Tahoma", Font.BOLD, 16));
		exch_currency.setBounds(236, 55, 76, 22);
		exchange_panel.add(exch_currency);

		JLabel exch_amount1 = new JLabel("999999.99");
		exch_amount1.setHorizontalAlignment(SwingConstants.RIGHT);
		exch_amount1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_amount1.setBounds(223, 79, 89, 29);
		exchange_panel.add(exch_amount1);

		JLabel exch_name1 = new JLabel("Exchange1");
		exch_name1.setHorizontalAlignment(SwingConstants.LEFT);
		exch_name1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_name1.setBounds(12, 79, 81, 29);
		exchange_panel.add(exch_name1);

		JLabel exch_type1 = new JLabel("BTC");
		exch_type1.setHorizontalAlignment(SwingConstants.LEFT);
		exch_type1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_type1.setBounds(104, 79, 51, 29);
		exchange_panel.add(exch_type1);

		JLabel label_11 = new JLabel("$");
		label_11.setHorizontalAlignment(SwingConstants.RIGHT);
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_11.setBounds(184, 79, 32, 29);
		exchange_panel.add(label_11);

		JLabel exch_name2 = new JLabel("Exchange2");
		exch_name2.setHorizontalAlignment(SwingConstants.LEFT);
		exch_name2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_name2.setBounds(12, 105, 81, 29);
		exchange_panel.add(exch_name2);

		JLabel exch_type2 = new JLabel("BTC");
		exch_type2.setHorizontalAlignment(SwingConstants.LEFT);
		exch_type2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_type2.setBounds(104, 105, 51, 29);
		exchange_panel.add(exch_type2);

		JLabel label_14 = new JLabel("$");
		label_14.setHorizontalAlignment(SwingConstants.RIGHT);
		label_14.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_14.setBounds(184, 105, 32, 29);
		exchange_panel.add(label_14);

		JLabel exch_amount2 = new JLabel("999999.99");
		exch_amount2.setHorizontalAlignment(SwingConstants.RIGHT);
		exch_amount2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_amount2.setBounds(233, 105, 79, 29);
		exchange_panel.add(exch_amount2);

		JLabel exch_name3 = new JLabel("Exchange3");
		exch_name3.setHorizontalAlignment(SwingConstants.LEFT);
		exch_name3.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_name3.setBounds(12, 132, 81, 29);
		exchange_panel.add(exch_name3);

		JLabel exch_type3 = new JLabel("BTC");
		exch_type3.setHorizontalAlignment(SwingConstants.LEFT);
		exch_type3.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_type3.setBounds(104, 132, 51, 29);
		exchange_panel.add(exch_type3);

		JLabel label_18 = new JLabel("$");
		label_18.setHorizontalAlignment(SwingConstants.RIGHT);
		label_18.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_18.setBounds(184, 132, 32, 29);
		exchange_panel.add(label_18);

		JLabel exch_amount3 = new JLabel("999999.99");
		exch_amount3.setHorizontalAlignment(SwingConstants.RIGHT);
		exch_amount3.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_amount3.setBounds(229, 132, 83, 29);
		exchange_panel.add(exch_amount3);

		JLabel exch_name4 = new JLabel("Exchange4");
		exch_name4.setHorizontalAlignment(SwingConstants.LEFT);
		exch_name4.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_name4.setBounds(12, 159, 81, 29);
		exchange_panel.add(exch_name4);

		JLabel exch_type4 = new JLabel("BTC");
		exch_type4.setHorizontalAlignment(SwingConstants.LEFT);
		exch_type4.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_type4.setBounds(104, 159, 51, 29);
		exchange_panel.add(exch_type4);

		JLabel label_22 = new JLabel("$");
		label_22.setHorizontalAlignment(SwingConstants.RIGHT);
		label_22.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_22.setBounds(184, 159, 32, 29);
		exchange_panel.add(label_22);

		JLabel exch_amount4 = new JLabel("999999.99");
		exch_amount4.setHorizontalAlignment(SwingConstants.RIGHT);
		exch_amount4.setFont(new Font("Tahoma", Font.PLAIN, 16));
		exch_amount4.setBounds(229, 159, 83, 29);
		exchange_panel.add(exch_amount4);

		JLabel label_12 = new JLabel("=");
		label_12.setHorizontalAlignment(SwingConstants.LEFT);
		label_12.setFont(new Font("Tahoma", Font.BOLD, 16));
		label_12.setBounds(200, 55, 24, 22);
		exchange_panel.add(label_12);

		// ////////////////////////////////////////////////////////////////
		// Menubar
		// ///////////////////////////////////////////////////////////////
		JMenuBar menuBar = new JMenuBar();
		mainJFrame.setJMenuBar(menuBar);

		// File Menu
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);

		JMenu mnNew = new JMenu("New...");
		mnFile.add(mnNew);

		JMenuItem mntmWallet = new JMenuItem("Wallet");
		mntmWallet.setActionCommand("FileNewWallet");
		mntmWallet.addActionListener(this);
		mnNew.add(mntmWallet);

		JMenuItem mntmAccount = new JMenuItem("Account");
		mntmAccount.setActionCommand("FileNewAcct");
		mntmAccount.addActionListener(this);
		mnNew.add(mntmAccount);

		JMenuItem mntmExchange = new JMenuItem("Exchange");
		mntmExchange.setActionCommand("New Exchange");
		mntmExchange.addActionListener(this);
		mnNew.add(mntmExchange);

		JMenuItem mntmCreateBackup = new JMenuItem("Create Backup");
		mntmCreateBackup.setActionCommand("FileCreateBackup");
		mntmCreateBackup.addActionListener(this);
		mnFile.add(mntmCreateBackup);

		JMenuItem mntmRestoreFromBackup = new JMenuItem("Restore From Backup");
		mntmRestoreFromBackup.setActionCommand("FileRestoreBackup");
		mntmRestoreFromBackup.addActionListener(this);
		mnFile.add(mntmRestoreFromBackup);

		JMenuItem mntmExit = new JMenuItem("Exit...");
		mntmExit.setActionCommand("FileExit");
		mntmExit.addActionListener(this);
		mnFile.add(mntmExit);

		// View Menu
		JMenu mnView = new JMenu("View");
		menuBar.add(mnView);

		JMenuItem mntmCharts = new JMenuItem("Charts");
		mntmCharts.setActionCommand("ViewCharts");
		mntmCharts.addActionListener(this);
		mnView.add(mntmCharts);

		JMenuItem mntmSettings = new JMenuItem("Settings");
		mntmSettings.setActionCommand("ViewSettings");
		mntmSettings.addActionListener(this);
		mnView.add(mntmSettings);

		// Window Menu
		JMenu mnNewMenu = new JMenu("Window");
		menuBar.add(mnNewMenu);

		JMenuItem mntmMinimize = new JMenuItem("Minimize");
		mntmMinimize.setActionCommand("Minimize");
		mntmMinimize.addActionListener(this);
		mnNewMenu.add(mntmMinimize);

		JMenuItem mntmRestore = new JMenuItem("Restore");
		mntmRestore.setActionCommand("Restore");
		mntmRestore.addActionListener(this);
		mnNewMenu.add(mntmRestore);

		// Help Menu
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);

		JMenuItem mntmVideoTutorial = new JMenuItem("Video Tutorials");
		mntmVideoTutorial.setActionCommand("VideoTutorials");
		mntmVideoTutorial.addActionListener(this);
		mnHelp.add(mntmVideoTutorial);

		JMenuItem mntmFaqs = new JMenuItem("FAQs");
		mntmFaqs.setActionCommand("FAQs");
		mntmFaqs.addActionListener(this);
		mnHelp.add(mntmFaqs);

		JMenuItem mntmCheckForUpdates = new JMenuItem("Check for updates...");
		mntmCheckForUpdates.setActionCommand("CheckUpdates");
		mntmCheckForUpdates.addActionListener(this);
		mnHelp.add(mntmCheckForUpdates);

		JMenuItem mntmReportBug = new JMenuItem("Report bug...");
		mntmReportBug.setActionCommand("ReportBug");
		mntmReportBug.addActionListener(this);
		mnHelp.add(mntmReportBug);

		JMenuItem mntmAbout = new JMenuItem("About...");
		mntmAbout.setActionCommand("About");
		mntmAbout.addActionListener(this);
		mnHelp.add(mntmAbout);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		// System.out.println("Action: " + e.getActionCommand());

		// Buttons
		if (e.getActionCommand() == "New Wallet") {
			createNewWallet();

		} else if (e.getActionCommand() == "New Acct") {
			createNewAcct();

		} else if (e.getActionCommand() == "New Exchange") {
			manageExchanges();

		} else if (e.getActionCommand() == "New Address") {
			newAddress();

		} else if (e.getActionCommand() == "SEND") {
			confirmSend();

		} else if (e.getActionCommand() == "Copy Address") {
			copyAddress();

		} else if (e.getActionCommand() == "Copy QR") {
			copyQRcode();

		} else if (e.getActionCommand() == "EXCHANGE") {
			initiateExchange();

		} else if (e.getActionCommand() == "Purge History") {
			purgeHistory();

		}

		// File Menu
		if (e.getActionCommand() == "FileNewWallet") {
			createNewWallet();

		} else if (e.getActionCommand() == "FileNewAcct") {
			createNewAcct();

		} else if (e.getActionCommand() == "FileNewExchange") {
			createNewExchange();

		} else if (e.getActionCommand() == "FileCreateBackup") {
			createBackup();

		} else if (e.getActionCommand() == "FileRestoreBackup") {
			restoreBackup();

		} else if (e.getActionCommand() == "FileExit") {
			System.exit(0);
		}

		// View Menu
		if (e.getActionCommand() == "ViewCharts") {
			viewCharts();

		} else if (e.getActionCommand() == "ViewSettings") {
			viewSettings();
		}

		// Window Menu
		if (e.getActionCommand() == "Minimize") {
			mainJFrame.setState(JFrame.ICONIFIED);

		} else if (e.getActionCommand() == "Restore") {
			mainJFrame.setState(JFrame.NORMAL);
		}

		// Help Menu
		if (e.getActionCommand() == "VideoTutorials") {
			openVideoTutorials();

		} else if (e.getActionCommand() == "FAQs") {
			openFAQS();

		} else if (e.getActionCommand() == "CheckUpdates") {
			checkUpdates();

		} else if (e.getActionCommand() == "ReportBug") {
			reportBug();

		} else if (e.getActionCommand() == "About") {
			// Custom button text
			Object[] options = { "OK" };
			JOptionPane.showOptionDialog(mainJFrame, aboutString, "About "
					+ titleString, JOptionPane.OK_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

		}

	}// END CONSTRUCTOR

	private void newAddress() {
		// TODO complete new address function
		try {
			Dialog_NewAddress dialog = new Dialog_NewAddress();
			dialog.setTitle("Add New Address");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
			dialog.setVisible(true);

		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}

	private void reportBug() {
		try {
			java.awt.Desktop.getDesktop().browse(
					java.net.URI.create(reportBugURL));

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void checkUpdates() {
		// TODO check and apply updates
		try {
			Dialog_CheckUpdates dialog = new Dialog_CheckUpdates();
			dialog.setTitle("Check for Updates");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
			dialog.setVisible(true);

		} catch (Exception e2) {
			e2.printStackTrace();
		}

	}

	private void openFAQS() {
		try {
			java.awt.Desktop.getDesktop().browse(java.net.URI.create(FAQURL));

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void openVideoTutorials() {
		// TODO setup Video Tutorial

	}

	private void viewSettings() {
		try {
			Dialog_Settings dialog = new Dialog_Settings();
			dialog.setTitle("Settings");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
			dialog.setVisible(true);

		} catch (Exception e2) {
			e2.printStackTrace();
		}

	}

	private void viewCharts() {
		try {
			Dialog_ViewCharts dialog = new Dialog_ViewCharts();
			dialog.setTitle("Charts");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setModalityType(Dialog.ModalityType.DOCUMENT_MODAL);
			dialog.setVisible(true);

		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}

	private void restoreBackup() {
		try {
			Dialog_RestoreBackup dialog = new Dialog_RestoreBackup();
			dialog.setTitle("Restore from Backup");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
			dialog.setVisible(true);

		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}

	private void createBackup() {
		try {
			Dialog_CreateBackup dialog = new Dialog_CreateBackup();
			dialog.setTitle("Create Backup");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
			dialog.setVisible(true);

		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}

	private void createNewExchange() {
		// TODO Auto-generated method stub

	}

	private void purgeHistory() {
		// TODO Auto-generated method stub
		JOptionPane
				.showOptionDialog(
						mainJFrame,
						"Are you sure you want to Purge History? You cannot undo this.",
						"Purge History?", JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.QUESTION_MESSAGE, null, null, null);

	}

	private void initiateExchange() {
		// TODO Auto-generated method stub
		try {
			Dialog_Exchange dialog = new Dialog_Exchange();
			dialog.setTitle("Start an Exchange");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
			dialog.setVisible(true);

		} catch (Exception e2) {
			e2.printStackTrace();
		}

	}

	private void copyQRcode() {
		// TODO Complete Copy QR function

	}

	private void copyAddress() {
		// TODO Complete Copy Address function

	}

	private void confirmSend() {
		// TODO Send: handle OK and CANCEL
		JOptionPane.showOptionDialog(mainJFrame,
				"Are you sure you want to send this request?", "Send Request?",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,
				null, null, null);

	}

	private void manageExchanges() {
		try {
			Dialog_NewExchange dialog = new Dialog_NewExchange();
			dialog.setTitle("Create New Exchange");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
			dialog.setVisible(true);

		} catch (Exception e2) {
			e2.printStackTrace();
		}

	}

	private void createNewAcct() {
		try {
			Dialog_NewAcct dialog = new Dialog_NewAcct();
			dialog.setTitle("Create New Account");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
			dialog.setVisible(true);

		} catch (Exception e2) {
			e2.printStackTrace();
		}

	}

	private void createNewWallet() {
		try {
			Dialog_NewWallet dialog = new Dialog_NewWallet();
			dialog.setTitle("Create New Wallet");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
			dialog.setVisible(true);

		} catch (Exception e2) {
			e2.printStackTrace();
		}

	}
}// END CLASS
