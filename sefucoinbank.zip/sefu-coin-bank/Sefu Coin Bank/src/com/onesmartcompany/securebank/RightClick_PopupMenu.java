package com.onesmartcompany.securebank;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

public class RightClick_PopupMenu extends JPopupMenu implements ActionListener {
	JList list;
	int listIndex;

	public RightClick_PopupMenu(JList jlist) {
		// TODO Add menu items to right click popup menus
		this.list = jlist;
		this.listIndex = list.getSelectedIndex();

		JMenuItem anItem = new JMenuItem("Edit...");
		JMenuItem anItem2 = new JMenuItem("Delete");

		anItem.addActionListener(this);
		anItem2.addActionListener(this);

		add(anItem);
		add(anItem2);

	}// END CONSTRUCTOR

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO get which list item was clicked and what to do
		if (e.getActionCommand().equals("Edit...")) {
			System.out.println("EDIT: " + listIndex);
		} else if (e.getActionCommand().equals("Delete")) {
			System.out.println("DELETE: " + listIndex);
		}

	}

}// END CLASS
